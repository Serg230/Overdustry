# Overdustry v1.0
Mindustry vanilla-like mod made by Serg230 that adds 12 new blocks, 2 items and 1 liquid.
Mod is on early development stage
Languages:
English
Russian
## Links
[Trello board that project](https://trello.com/b/2KFlz7eY/overdustry)
[VK group](https://vk.com/club207580587)